  #

import pathlib
import logging
import sqlite3 as db
from tabulate import tabulate
import datetime

class Database:


    def __init__(self) -> None:    
        self.con = db.connect(f"betdata.db" , detect_types=db.PARSE_DECLTYPES, check_same_thread = False)
        self.c=self.con.cursor()#banner INT 
        self.c.execute('CREATE TABLE IF NOT EXISTS Users (Name TEXT , User_id INT PRIMARY KEY , Username TEXT, Invited INT, Join_time TEXT )')
        self.c.execute('CREATE TABLE IF NOT EXISTS Admins (Name TEXT , User_id INT PRIMARY KEY , Join_time TEXT )')
        self.c.execute('CREATE TABLE IF NOT EXISTS Joins (Title TEXT , Chatid INT PRIMARY KEY , Link TEXT )')

        self.con.commit()
        print('DataBase Has Successfully Loaded') 
    
    
    def Add_User(self, data1, data2, data3, data4, data5) -> bool:

        self.c.execute(
            "INSERT OR IGNORE INTO Users VALUES(? ,?, ?, ?, ?);", [data1, data2, data3, data4, data5]
        )
        self.con.commit()
        return True


    def All_Data_Text(self) -> str:
        Text='--------------❈ 𝐁𝐨𝐭 𝐢𝐧𝐟𝐨 ❈---------------\n\n'
        Tabels={'Users':['Name','User_id','Username','Invited', 'Date']}
        for i in Tabels :
            Data=self.c.execute(f'SELECT * FROM {i}').fetchall()
            tab=tabulate(Data , Tabels[i],  tablefmt="grid")
            Text+=f"{tab} \n \n "
        return Text
    

    def All_Users(self):
        self.c.execute('SELECT User_id FROM Users')
        rows=self.c.fetchall()
        return rows

   
    def All_user_count(self) -> int:
        x = self.c.execute(f'SELECT COUNT(*) FROM Users')
        count = x.fetchall()[0][0]
        return count


    def select_invited(self, user_id):
        query = 'SELECT Invited FROM Users WHERE User_id = ?'
        self.c.execute(query, [user_id])
        rows = self.c.fetchone()
        self.con.commit
        return rows[0]
    
    def Add_admin(self, data1, data2, data3) -> bool:

        self.c.execute(
            "INSERT OR IGNORE INTO Admins VALUES(? ,?, ?);", [data1, data2, data3]
        )
        self.con.commit()
        return True

    def Del_admin(self, data1) -> bool:

        self.c.execute(
            "DELETE FROM Admins WHERE User_id = (?);", [data1]
        )
        self.con.commit()
        return True

    def User_id(self, user_id):
        query = 'SELECT User_id FROM Users WHERE User_id = ?'
        self.c.execute(query, [user_id])
        rows = self.c.fetchone()
        return rows
    
    def admin_User_id(self, user_id):
        query = 'SELECT User_id FROM Admins WHERE User_id = ?'
        self.c.execute(query, [user_id])
        rows = self.c.fetchone()
        return rows
    

    def User_info(self, user_id):
        query = 'SELECT name,username,Invited,Join_time FROM Users WHERE User_id = ?'
        self.c.execute(query, [user_id])
        rows = self.c.fetchone()
        self.con.commit()        
        text = f'✦ نام : {rows[0]}\n✦ یوزرنیم : {rows[1]}\n✦ تعداد دعوت به ربات : {rows[2]}\n✦ تاریخ عضویت در ربات : {rows[3]}'
        return text

    def User_information(self, user_id):
        query = 'SELECT name,username,Invited,Join_time FROM Users WHERE User_id = ?'
        self.c.execute(query, [user_id])
        rows = self.c.fetchone()
        self.con.commit()        
        text = (f'[✏️] اسم کاربر :  {rows[0]}\n'
                f'[🖇] آیدی عددی : <code>{user_id}</code>\n'
                f'[💠] یوزرنیم : <code>{rows[1]}</code>\n'
                f'[♟] تعداد زیر مجموعه : <code>{rows[2]}</code>\n'
                f'[⏳] تاریخ عضویت در ربات : <code>{rows[3]}</code>')

        return text
    


    def Admin_info(self, user_id):
        query = 'SELECT Name FROM Users WHERE User_id = ?'
        self.c.execute(query, [user_id])
        rows = self.c.fetchone()
        self.con.commit()   
        return rows[0]
        
    def All_Admin_Text(self) -> str:
        Text=''
        Tabels={'Admins':['Name','User_id','Admin_date']}
        for i in Tabels :
            Data=self.c.execute(f'SELECT * FROM {i}').fetchall()
            tab=tabulate(Data , Tabels[i],  tablefmt="rounded_grid")
            Text+=f"{tab} \n \n "
        return Text
    
    def update_data(self, user_id):
        query = f"UPDATE Users SET Invited=Invited +{1} WHERE User_id = ?;"
        self.c.execute(query, [user_id])
        self.con.commit()
        return True
    
  
db = Database()