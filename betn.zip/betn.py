import sys
import asyncio
from pyrogram import compose
from utils.clients import ApiClient
from utils.config import Clients

async def main():
    Clients.api = ApiClient()
    await compose([Clients.api], sequential=True)


loop = asyncio.get_event_loop()
loop.run_until_complete(main())