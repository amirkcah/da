from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup , InlineQueryResultArticle, InputTextMessageContent
from pyrogram.types.bots_and_keyboards import force_reply 
from utils.config import SETTINGS
Start = ReplyKeyboardMarkup([['💥 دریافت فرم رایگان 💥'],
                                ['🟢 سایت مورد تایید جهت شرطبندی 🟢'],
                                ['💰 زیرمجموعه گیری و کسب درآمد 💰'],
                                ['🤖 سایر ربات‌های ما 🤖'],
                                ['💬 ارتباط با پشتیبانی 💬']],resize_keyboard =True)
                                
                                
                               
bet_form = ReplyKeyboardMarkup([['🔥 تک بازی روزانه 🔥'],
                                ['💯 شوربت | شرطبندی بدون باخت 💯'],
                                ['🔄 بازگشت 🔄']],resize_keyboard =True)

Cancel=ReplyKeyboardMarkup([['❌ انصراف ❌']],resize_keyboard =True)

Site_link = ReplyKeyboardMarkup([['🔗 آدرس بدون فیلتر‌ 🔗'],
                                ['🔄 بازگشت 🔄']],resize_keyboard =True)                       

back_Bot = ReplyKeyboardMarkup([['🔄 بازگشت 🔄']],resize_keyboard =True)    

    

Link_bot =  ReplyKeyboardMarkup([['حساب من👤' , '🔗 لینک اختصاصی'],
                                 ['🔄 بازگشت 🔄']],resize_keyboard =True)   

Support = lambda username: InlineKeyboardMarkup(
    [
        [InlineKeyboardButton('📞 پشتیبانی', url=f'https://t.me/{username}')]
    ]
    )

Support_mange_1 = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton('📞 پشتیبانی', url=f"https://t.me/{SETTINGS['Sup_admin']}"),

        ]
        ,
        [
            InlineKeyboardButton('🔄 تغییر پشتیبانی ', callback_data=f'change_sup_admin'),

        ]
        ,
        [
            InlineKeyboardButton('برگشت 🔙', callback_data=f'back'),

        ]
        ])

Support_mange_2 = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton('➕ افزودن پشتیبانی ', callback_data=f'change_sup_admin'),

        ]
        ,
        [
            InlineKeyboardButton('برگشت 🔙', callback_data=f'back'),

        ]
        ])


Support_2 =  ReplyKeyboardMarkup([['📩 ارسال پیام مستقیم از طریق نجوا'],
                                ['💬 ارتباط با آیدی پشتیبانی'],
                                ['🔄 بازگشت 🔄']],resize_keyboard =True) 


Management =  InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton('ارسال پیام 📬', callback_data = 'send_message'),

        ]
        ,
        [
            InlineKeyboardButton('اطلاعات 🔭', callback_data=f'information'),

        ]
        ,
        [
            InlineKeyboardButton('تنظیمات ⚙️', callback_data=f'Settings'),

        ]
        ,
        [
            InlineKeyboardButton('راهنمای ربات 💡', callback_data=f'bot_help'),

        ]
        
        ,
        [
            InlineKeyboardButton('پنل اصلی 💎', callback_data=f'panel'),

        ]
        ,
        [
            InlineKeyboardButton('بستن ⭕️', callback_data=f'close'),
        ]

    ])

Message = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton('فروارد 🏷', callback_data = 'ّForward'),

        ]
        ,
        [
            InlineKeyboardButton('نجوا 📩', callback_data=f'Najva'),
            InlineKeyboardButton('تک نجوا 📤', callback_data=f'one_najva')

        ]
        
        ,
        [
            InlineKeyboardButton('برگشت 🔙', callback_data=f'back'),
        ]

    ])

Information = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton('اطلاعات کلی 📊', callback_data = 'bot_info'),

        ]
        ,
        [
            InlineKeyboardButton('اطلاعات کاربری 👥', callback_data=f'user_info'),

        ]
        ,
        [
            InlineKeyboardButton('برگشت 🔙', callback_data=f'back'),
        ]

    ])

back_info = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton('برگشت 🔙', callback_data=f'back_info'),
        ]

    ])

back_message = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton('برگشت 🔙', callback_data=f'back_message'),
        ]

    ])


Settings = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton('🧑🏻‍💻بخش ادمین ها ', callback_data=f'Admins_menu'),
        ]
        ,
        [
            InlineKeyboardButton('👥 تنظیم پشتیبانی ', callback_data=f'sup_inf'),

        ]
        ,
        [
            InlineKeyboardButton('تنظیم متن جوین اجباری 📝 ', callback_data=f'join_tx'),

        ]
        ,
        [
            InlineKeyboardButton('تنظیم جوین اجباری 🔒', callback_data=f'Set_join'),

        ]
        ,
        [
            InlineKeyboardButton('برگشت 🔙', callback_data=f'back'),
        ]

    ])

back_setting = InlineKeyboardMarkup(
    [

        [
            InlineKeyboardButton('برگشت 🔙', callback_data=f'back_setting'),
        ]

    ])


admin_manage = InlineKeyboardMarkup(
    [

        [
            InlineKeyboardButton('➕ افزودن ادمین', callback_data=f'Add_admin'),
        ]
        ,
        [
            InlineKeyboardButton('➖ حذف ادمین', callback_data=f'del_admin'),

        ],
        [
            InlineKeyboardButton('برگشت 🔙', callback_data=f'back'),

        ]

    ])

   
send_message = InlineKeyboardMarkup(
    [

        [
            InlineKeyboardButton('ارسال پیام ✏️', callback_data=f'send_m'),
        ]
        ,
        [
             InlineKeyboardButton('بستن ⭕️', callback_data=f'close_m'),

        ]
    ])

send_javab = InlineKeyboardMarkup(
    [

        [
            InlineKeyboardButton('ارسال پیام ✏️', callback_data=f'send_javb'),
        ]
        ,
        [
             InlineKeyboardButton('بستن ⭕️', callback_data=f'close_m'),

        ]
    ])

Help = InlineKeyboardMarkup(
    [

        [
            InlineKeyboardButton('دستورات ⚜️', callback_data=f'Dastour'),
        ],

        [
            InlineKeyboardButton('آموزش ها 🔅', callback_data=f'learn'),

        ]
        ,
        [
             InlineKeyboardButton('برگشت 🔙', callback_data=f'back_help'),

        ]
    ])

Help_back_ = InlineKeyboardMarkup(
    [

        [
             InlineKeyboardButton('برگشت 🔙', callback_data=f'BAck_h'),

        ]
    ])


javab_admin= InlineKeyboardMarkup(
    [

        [
            InlineKeyboardButton('ارسال پیام ✏️', callback_data=f'send_javb_admin'),
        ]
        ,
        [
             InlineKeyboardButton('بستن ⭕️', callback_data=f'close_m'),

        ]
    ])

set_join= InlineKeyboardMarkup(
    [

        [
            InlineKeyboardButton('➕ اضافه کردن قفل 🔏 ', callback_data=f'set_ch'),
        ]
        ,
        [
            InlineKeyboardButton('➖  حذف کردن قفل 🔓 ', callback_data=f'del_ch'),
        ]
        ,
        [
             InlineKeyboardButton('برگشت 🔙', callback_data=f'back'),

        ]
    ])
