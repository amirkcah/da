# -*- coding: utf-8 -*-
from pyrogram import filters, enums
from pyrogram.types import Message
from .config import SUDO, LINKS, channel_ids
from utils.config import Clients , SETTINGS, channel_links
from utils import Buttons
from pyrogram.errors import UserNotParticipant
from pyrogram.types import InlineKeyboardMarkup, InlineKeyboardButton, ReplyKeyboardMarkup , InlineQueryResultArticle, InputTextMessageContent
from data.database import db


async def keyboard_maker(data: list) -> InlineKeyboardMarkup:
    _keys = []
    for k, v in SETTINGS['channel_link'].items():
        _keys.append([
            InlineKeyboardButton(
                text = f"{k}",
                url = v
            )
        ])
    _keys.append([
        InlineKeyboardButton(
            text = "✅ جوین شدم",
            callback_data = "joine_ok"
        )
    ])
    return InlineKeyboardMarkup(_keys)

            

    
async def is_joined(_ , __, m):
    not_joined = []
    
    for k, v in SETTINGS['channel_ids'].items():
        try:

            member  = await Clients.api.get_chat_member(
                int(k),
                user_id = m.from_user.id
            )
            if member.status in (enums.ChatMemberStatus.LEFT, enums.ChatMemberStatus.BANNED):
                not_joined.append(k)
                return
        except:
            not_joined.append(k)


        
    if not_joined:
        await m.reply(f'🔊 کاربر گرامی 🔊\n'
                    f'برای «استفاده از ربات» حتما می‌بایست در کانال و گپ‌های ما عضو باشید 🌸\n'
                    f'بعد از عضـویت، گزینه « تایید عضویت ✅️ » را ارسال کنید تا ربات برای شما فعال شود. 👇',
        reply_markup = await keyboard_maker(channel_links))

    else:    
        return True





async def is_admin(_, __, msg: Message):
    """
    Check that the command was sent by the administrators
    """
    try:
        return msg.from_user and (msg.from_user.id in SUDO or msg.from_user.id in db.admin_User_id(msg.from_user.id))
    except:
        pass




admin_cm = filters.create(is_admin)
check = filters.create(is_joined)

