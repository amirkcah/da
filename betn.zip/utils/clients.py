from pyrogram import Client
from utils.config import API_ID, API_HASH, BOT_TOKEN
import uvloop
uvloop.install()
import pyromod
from pyromod import listen

class ApiClient(Client):
    def __init__(self):
        super().__init__(
            'api',
            api_id=API_ID,
            api_hash=API_HASH,
            plugins=dict(root='plugins.api'),
            bot_token=BOT_TOKEN
        )

