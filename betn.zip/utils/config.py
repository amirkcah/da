from os.path import isfile
from pickle import load
from pyrogram import Client

API_ID = 15587752
API_HASH = '56c25355a160a391fdceb7f82d6a6197'
SUDO = [5823435734,1009678891]
BOT_TOKEN = '6347049233:AAFO3aQWSaKWrI2wtr7jcha0khB58Tiu0c0'
LINKS = ['-1002237532190']
channel_ids = ['chsnelbet']
class Clients:
    api: Client = None
    cli: Client = None

channel_links: list = []

if isfile('settings.pkl'):
    with open('settings.pkl', 'rb') as f:
        SETTINGS = load(f)
else:
    SETTINGS = {
        'channel_ids': {},
        'channel_link': {},
        'ourbots': 0,
        'takgame': 0,
        'over': 0,
        'site_baner': 0,
        'link_site': 0,
        'link_baner': 0,
        'text_baner': 0,
        'Sup_admin': "",
        'join_tx': "",
    }
