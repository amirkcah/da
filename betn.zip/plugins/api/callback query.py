# -*- coding: utf-8 -*-
from pyrogram import filters, Client, enums
from pyrogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from utils.clients import ApiClient
from utils.config import SUDO, SETTINGS
from utils.filters import admin_cm
from pickle import dump
from utils import Buttons
from data.database import db
import jdatetime as jdf
from os import remove as os_remove

import jdatetime as jdf



def save_settings():
    with open('settings.pkl', 'wb') as f:
        dump(SETTINGS, f)

@ApiClient.on_callback_query(admin_cm & filters.regex('^back_info') , group=0)
async def on_click_(bot: Client, cl: CallbackQuery):
    await cl.message.edit_text(f'لطفا نوع اطلاعات مورد نظر خودتون رو انتخاب کنید 👇🏻',
                                    reply_markup = Buttons.Information)


@ApiClient.on_callback_query(filters.regex('^back_message') , group=0)
async def back_message(bot: Client, cl: CallbackQuery):
    await cl.message.edit_text(f'لطفا نوع اطلاعات مورد نظر خودتون رو انتخاب کنید 👇🏻',
                                    reply_markup = Buttons.Message)


@ApiClient.on_callback_query(filters.regex('^joine_ok') , group=0)
async def join_check(bot: Client, cl: CallbackQuery):
    user_id = cl.from_user.id
    user_fullname = cl.from_user.first_name
    username = cl.from_user.username
    Date = jdf.date.today().strftime("%Y/%m/%d")

    not_joined = []
    for channel in SETTINGS['channel_ids']:
        try:
            member = await bot.get_chat_member(chat_id = int(channel) , user_id = user_id)
            if member.status in (enums.ChatMemberStatus.LEFT, enums.ChatMemberStatus.BANNED):
                not_joined.append(channel)
                return
        except Exception as e:
            not_joined.append(channel)



    if not_joined:
        await cl.answer(f"شما هنوز در کانال‌ها و گپ عضو نشدید ⚠️", show_alert = False)
    else:
        await bot.delete_messages(cl.from_user.id, cl.message.id)
        await bot.send_message(user_id, f'✦ به اولین و پیشرفته‌ترین ربات شرطبندی تک بازی در تلگرام خوش آمدید 🤖\n❇️ ارائه روزانه یک فرم سیف و مطمئن ❇️\n✦ برای استفاده از ربات، لطفا گزینه مورد نظر خود را انتخاب کنید 👇🏻',
        reply_markup = Buttons.Start) 
        if not db.User_id(user_id):
            db.Add_User(user_fullname, user_id, username,0,Date)
            for sudo in SUDO:
                await bot.send_message(sudo, f'◈ کـاربر {user_fullname}\n ◂ آیدی : {user_id}\nعضو ربات شد 🎉')



@ApiClient.on_callback_query(admin_cm & filters.regex('^panel') , group=0)
async def Bot_panel(bot: Client, cl: CallbackQuery):

    user_id = cl.from_user.id
    await bot.delete_messages(cl.from_user.id, cl.message.id)
    await bot.send_message(user_id, f'✦ به اولین و پیشرفته‌ترین ربات شرطبندی تک بازی در تلگرام خوش آمدید 🤖\n❇️ ارائه روزانه یک فرم سیف و مطمئن ❇️\n✦ برای استفاده از ربات، لطفا گزینه مورد نظر خود را انتخاب کنید 👇🏻',
        reply_markup = Buttons.Start) 

@ApiClient.on_callback_query(admin_cm & filters.regex('^send_message') , group=0)
async def send_message(bot: Client, cl: CallbackQuery):
    await cl.message.edit_text(f'لطفا نوع پیام مورد نظر خودتون رو انتخاب کنید 👇🏻',
                                   reply_markup = Buttons.Message)


@ApiClient.on_callback_query(admin_cm & filters.regex('^back') , group=0)
async def back_menu(bot: Client, cl: CallbackQuery):
    await cl.message.edit_text(f'سلام مدیر 💎\n🔧 از منوی زیر میتونید ربات را کنترل کنید 🔧',
                                               reply_markup = Buttons.Management) 
    
    
@ApiClient.on_callback_query(admin_cm & filters.regex('^information') , group=0)
async def bot_info_kind(bot: Client, cl: CallbackQuery):
    await cl.message.edit_text(f'لطفا نوع اطلاعات مورد نظر خودتون رو انتخاب کنید 👇🏻',
                                            reply_markup = Buttons.Information)

    
@ApiClient.on_callback_query(admin_cm & filters.regex('^bot_info') , group=0)
async def bot_all_info(bot: Client, cl: CallbackQuery):
    user_id = cl.from_user.id
    await cl.message.edit_text(f'مدیر گرامی لطفا صبور باشید ❕\nدرحال گرفتن آمار ربات .....',
                                reply_markup = Buttons.back_info)
    t = db.All_Data_Text()
    c = db.All_user_count()
    with open("Bot_info.html", "a", encoding="utf-8") as f:
        f.write(t)   
    await bot.send_document(user_id, "Bot_info.html", caption = f'👥 Count : {c}')
    os_remove("Bot_info.html")

    
@ApiClient.on_callback_query(admin_cm & filters.regex('user_info') , group=0)
async def user_info(bot: Client, cl: CallbackQuery):
    await bot.delete_messages(cl.from_user.id, cl.message.id)

    try:
        text=((await bot.ask(cl.from_user.id,'<b>لطفا یوزر آِیدی کاربر مورد نظر رو ارسال کنید !</b>',filters=filters.text ,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass

    while not text.text.isdigit() and text.text !='❌ انصراف ❌':
        try:
            text=((await bot.ask(cl.from_user.id,'<b>لطفا یوزر آِیدی کاربر مورد نظر رو ارسال کنید !</b>',filters=filters.text ,reply_markup=Buttons.Cancel,timeout=120)))
        except TimeoutError :pass
 
    if text.text == '❌ انصراف ❌':
        await bot.send_message(text.from_user.id, f'سلام مدیر 💎\n🔧 از منوی زیر میتونید ربات را کنترل کنید 🔧', 
        reply_markup = Buttons.Management)
    
    else:
        if db.User_id(int(text.text)):
            t = db.User_info(int(text.text))
            await bot.send_message(cl.from_user.id, t,
                                   reply_markup = Buttons.back_info)
        else:
            await bot.send_message(cl.from_user.id, '<b>✦  کاربر مورد نظر یافت نشد !</b>',
                                   reply_markup = Buttons.back_info)


@ApiClient.on_callback_query(admin_cm & filters.regex('ّForward') , group=0)
async def Forward_message(bot: Client, cl: CallbackQuery):
    await bot.delete_messages(cl.from_user.id, cl.message.id)
    try:
        message=((await bot.ask(cl.from_user.id,'<b>شما در حال فروارد پیام به تمام کاربرای ربات هستین !\nلطفا پیام خود را بفرستین !</b>' ,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :  
        await bot.send_message(cl.from_user.id, f'<b>زمان ارسال تمام شد ! \n دوباره سعی کنید !</b>',
                               reply_markup = Buttons.back_message)

    if message.text == '❌ انصراف ❌':
        await bot.send_message(message.from_user.id, f'لطفا نوع پیام مورد نظر خودتون رو انتخاب کنید 👇🏻', 
        reply_markup = Buttons.Message)

    else:
        x = 0
        a = db.All_Users()
        for i in a:
            for b in i:
                    await message.forward(int(b))
                    x += 1
            
        await bot.send_message(cl.from_user.id, f'پیام با موفقیت به {x} کاربرای ربات ارسال شد !',
                                reply_markup = Buttons.back_message)



@ApiClient.on_callback_query(admin_cm & filters.regex('Najva') , group=0)
async def copy_message(bot: Client, cl: CallbackQuery):
    await bot.delete_messages(cl.from_user.id, cl.message.id)

    try:
        message=((await bot.ask(cl.from_user.id,'<b>شما در حال ارسال پیام به تمام کاربرای ربات هستین !\nلطفا پیام خود را بفرستین !</b>' ,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :  
        await bot.send_message(cl.from_user.id, f'<b>زمان ارسال تمام شد ! \n دوباره سعی کنید !</b>',
                               reply_markup = Buttons.back_message)
        return

    if message.text == '❌ انصراف ❌':
        await bot.send_message(message.from_user.id, f'سلام مدیر 💎\n🔧 از منوی زیر میتونید ربات را کنترل کنید 🔧', 
        reply_markup = Buttons.Message)

    else:

        x = 0
        a = db.All_Users()
        for i in a:
            for b in i:
                    await message.copy(int(b))
                    x += 1
            
        await bot.send_message(cl.from_user.id, f'پیام با موفقیت به {x} کاربرای ربات ارسال شد !',
                                reply_markup = Buttons.back_message)


@ApiClient.on_callback_query(admin_cm & filters.regex('one_najva') , group=0)
async def one_copy_message(bot: Client, cl: CallbackQuery):
    await bot.delete_messages(cl.from_user.id, cl.message.id)
    try:
        user_id=((await bot.ask(cl.from_user.id,'<b>لطفا یوزر آِیدی کاربر مورد نظر رو ارسال کنید !</b>',filters=filters.text ,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass
    
    if user_id.text == '❌ انصراف ❌':
        await bot.send_message(text.from_user.id, f'سلام مدیر 💎\n🔧 از منوی زیر میتونید ربات را کنترل کنید 🔧', 
        reply_markup = Buttons.Management)
    
    while not user_id.text.isdigit() and user_id.text !='❌ انصراف ❌':
        try:
            text=((await bot.ask(cl.from_user.id,'<b>لطفا یوزر آِیدی کاربر مورد نظر رو ارسال کنید !</b>',filters=filters.text ,reply_markup=Buttons.Cancel,timeout=120)))
        except TimeoutError :pass
    else:
        if db.User_id(int(user_id.text)):
            try:
                message=((await bot.ask(cl.from_user.id,'<b>شما در حال ارسال پیام به کاربر مورد نظر ربات هستین !\nلطفا پیام خود را بفرستین !</b>' ,reply_markup=Buttons.Cancel,timeout=120)))
            except TimeoutError :  
                await bot.send_message(cl.from_user.id, f'<b>زمان ارسال تمام شد ! \n دوباره سعی کنید !</b>',
                                    reply_markup = Buttons.Message)
            await message.copy(int(user_id.text))
            await bot.send_message(cl.from_user.id, 'پیام به کاربر مورد نظر ارسال شد !',
                                   reply_markup = Buttons.back_message)
        else:
            await bot.send_message(cl.from_user.id, '<b>✦  کاربر مورد نظر یافت نشد !</b>',
                                   reply_markup = Buttons.back_message)


@ApiClient.on_callback_query(admin_cm & filters.regex('Settings') , group=0)
async def Bot_Settings(bot: Client, cl: CallbackQuery):
    await cl.message.edit_text(f'لطفا گزینه مورد نظر خودتون رو انتخاب کنید 👇🏻',
                                reply_markup = Buttons.Settings)


@ApiClient.on_callback_query(admin_cm & filters.regex('Admins_menu') , group=0)
async def Admins_bot(bot: Client, cl: CallbackQuery):
    a = db.All_Admin_Text()
    await cl.message.edit_text(f'{a}',
                                reply_markup = Buttons.admin_manage)

@ApiClient.on_callback_query(filters.user(SUDO) & filters.regex('Add_admin') , group=0)
async def Add_admin(bot: Client, cl: CallbackQuery):
    Date = jdf.date.today().strftime("%Y/%m/%d")
    await bot.delete_messages(cl.from_user.id, cl.message.id)
    try:
        user_id=((await bot.ask(cl.from_user.id,'<b>لطفا یوزر آِیدی کاربر مورد نظر رو ارسال کنید !</b>',filters=filters.text ,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass
    
    if user_id.text == '❌ انصراف ❌':
        await bot.send_message(user_id.from_user.id, f'سلام مدیر 💎\n🔧 از منوی زیر میتونید ربات را کنترل کنید 🔧', 
        reply_markup = Buttons.Management)
    

    while not user_id.text.isdigit() and user_id.text !='❌ انصراف ❌':
        try:
            user_id=((await bot.ask(cl.from_user.id,'<b>لطفا یوزر آِیدی کاربر مورد نظر رو ارسال کنید !</b>',filters=filters.text ,reply_markup=Buttons.Cancel,timeout=120)))
        except TimeoutError :pass
    else:
        if db.User_id(int(user_id.text)):
            if not db.admin_User_id(int(user_id.text)):

                a = db.User_info(int(user_id.text))
                name = db.Admin_info(int(user_id.text))
                db.Add_admin(name, int(user_id.text), Date )
                await bot.send_message(cl.from_user.id,f'•  اطلاعات ادمین جدید شما👇🏻\n {a}',
                                    reply_markup = Buttons.back_setting)
                await bot.send_message(int(user_id.text),f'✅ شما با موفقیت به ادمین های ربات اضافه شدید لطفا ربات رو استارت کنید. \n/start')
                
            else:
                await bot.send_message(cl.from_user.id,f'•  کاربر مورد نظر شما در لیست ادمین هست !',
                        reply_markup = Buttons.back_setting)



        else:
            await bot.send_message(cl.from_user.id,f'•  کاربر مورد نظر شما ربات را استارت نکرده !',
                                   reply_markup = Buttons.back_setting)



@ApiClient.on_callback_query(filters.user(SUDO) & filters.regex('del_admin') , group=0)
async def del_admin(bot: Client, cl: CallbackQuery):
    await bot.delete_messages(cl.from_user.id, cl.message.id)
    try:
        user_id=((await bot.ask(cl.from_user.id,'<b>لطفا یوزر آِیدی کاربر مورد نظر رو ارسال کنید !</b>',filters=filters.text ,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass
    
    if user_id.text == '❌ انصراف ❌':
        await bot.send_message(user_id.from_user.id, f'سلام مدیر 💎\n🔧 از منوی زیر میتونید ربات را کنترل کنید 🔧', 
        reply_markup = Buttons.Management)
    

    while not user_id.text.isdigit() and user_id.text !='❌ انصراف ❌':
        try:
            user_id=((await bot.ask(cl.from_user.id,'<b>لطفا یوزر آِیدی کاربر مورد نظر رو ارسال کنید !</b>',filters=filters.text ,reply_markup=Buttons.Cancel,timeout=120)))
        except TimeoutError :pass
    else:
        if db.User_id(int(user_id.text)):
            if db.admin_User_id(int(user_id.text)):

                a = db.User_info(int(user_id.text))
                db.Del_admin(int(user_id.text))

                await bot.send_message(cl.from_user.id,f'•  اطلاعات ادمین پاک شده شما👇🏻\n {a}',
                                    reply_markup = Buttons.back_setting)
                await bot.send_message(int(user_id.text),f'! شما از ادمین های ربات پاک  شدید لطفا ربات رو استارت کنید. \n/start')
                
            else:
                await bot.send_message(cl.from_user.id,f'•  کاربر مورد نظر شما در لیست ادمین نیست !',
                        reply_markup = Buttons.back_setting)


        else:
            await bot.send_message(cl.from_user.id,f'•  کاربر مورد نظر شما ربات را استارت نکرده !',
                                   reply_markup = Buttons.back_setting)

@ApiClient.on_callback_query(filters.regex('close') , group=0)
async def close(bot: Client, cl: CallbackQuery):
    await bot.delete_messages(cl.from_user.id, cl.message.id)

@ApiClient.on_callback_query(admin_cm & filters.regex('sup_inf') , group=0)
async def sup_bot(bot: Client, cl: CallbackQuery):
    try:
        await cl.message.edit_text(f'لطفا گزینه مورد نظر خودتون رو انتخاب کنید 👇🏻',
                            reply_markup = Buttons.Support_mange_1)

    except:
        await cl.message.edit_text(f'لطفا گزینه مورد نظر خودتون رو انتخاب کنید 👇🏻',
                            reply_markup = Buttons.Support_mange_2)

@ApiClient.on_callback_query(admin_cm & filters.regex('change_sup_admin') , group=0)
async def add_sup_bot(bot: Client, cl: CallbackQuery):
    await bot.delete_messages(cl.from_user.id, cl.message.id)

    try:
        user=((await bot.ask(cl.from_user.id,'<b>لطفا یوزرنیم  کاربر پشتیبان نظر رو ارسال کنید !</b>',filters=filters.text ,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass
    SETTINGS['Sup_admin'] = user.text
    save_settings()
    await bot.send_message(cl.from_user.id, f'لطفا گزینه مورد نظر خودتون رو انتخاب کنید 👇🏻',
                            reply_markup = Buttons.Support_mange_1)


@ApiClient.on_callback_query(admin_cm & filters.regex('join_tx') , group=0)
async def join_tex_bot(bot: Client, cl: CallbackQuery):
    text = SETTINGS['join_tx']
    if text:
        await cl.message.edit_text(f'متن تنظیم شده 👇🏻\n\n{text}',
                            reply_markup = Buttons.back_setting)
    else:
        await  cl.message.edit_text(f'متن پیش فرض 👇🏻\n\n◈ کاربر NAME\n'
                                                f'◈ از طرف لینک اختصاصی شما وارد ربات شد !\n'
                                                f'◂ توجه داشته باشید افرادی که دعوت میکنید حتما باید بت باز باشن در غیر این صورت چیزی نمیگیرید\n'
                                                f'◂ میتونید لینکتون رو به رفیقای بت بازتون یا ممبرای سایر گپای بت ارسال کنید\n'
                                                f'┈┅┅━━━━━━✦━━━━━━┅┅┈\n'
                                                f'❇️ تعداد افراد دعوت شده توسط شما : NUM',
                    reply_markup = Buttons.back_setting)



@ApiClient.on_callback_query(admin_cm & filters.regex('send_m') , group=0)
async def send_m_user_bot(bot: Client, cl: CallbackQuery):
    name = cl.message.text.split(' کـاربر : ')[1].split('\n')[0]
    user_id = cl.message.text.split(' آیدی : ')[1].split('\n')[0]
    try:
        text=((await bot.ask(cl.from_user.id,f'<b>شما در حال ارسال پیام به کاربر {name}  می باشید !</b>\nلطفا پیام خود را وارد کنید !',filters=filters.text ,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass

    if text.text == '❌ انصراف ❌':
        await bot.send_message(cl.from_user.id, f'سلام مدیر 💎\n🔧 از منوی زیر میتونید ربات را کنترل کنید 🔧', 
            reply_markup = Buttons.Management)
    
    else:
        await text.copy(user_id)
        await bot.send_message(cl.from_user.id, f'پیام با موفقیت ارسال شد ✅\nپیام 👇🏻 : \n\n{text.text}')


@ApiClient.on_callback_query(admin_cm & filters.regex('send_javb') , group=0)
async def send_l_user_bot(bot: Client, cl: CallbackQuery):
    print(cl.message.caption)
    try:
        name = cl.message.text.split(' کـاربر : ')[1].split('\n')[0]
        user_id = cl.message.text.split(' آیدی : ')[1].split('\n')[0]
    except:
        name = cl.message.caption.split(' کـاربر : ')[1].split('\n')[0]
        user_id = cl.message.caption.split(' آیدی : ')[1].split('\n')[0]

    try:
        text=((await bot.ask(cl.from_user.id,f'<b>شما در حال ارسال پیام به کاربر {name}  می باشید !</b>\nلطفا پیام خود را وارد کنید !',reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass

    if text.text == '❌ انصراف ❌':
        await bot.send_message(cl.from_user.id, f'سلام مدیر 💎\n🔧 از منوی زیر میتونید ربات را کنترل کنید 🔧', 
            reply_markup = Buttons.Management)
    
    else:
        javab_admin= InlineKeyboardMarkup(
    [

        [
            InlineKeyboardButton('ارسال پیام ✏️', callback_data=f'send_javb_admin{user_id}'),
        ]
        ,
        [
             InlineKeyboardButton('بستن ⭕️', callback_data=f'close_m'),

        ]
    ])
        if text.text:
            await bot.send_message(user_id, f'- پیام از طرف مدیریت 💎\n\n{text.text}',
                                   reply_markup = javab_admin)
        else:
            await text.copy(user_id, caption = '- پیام از طرف مدیریت 💎',
                            reply_markup =  javab_admin)
        
        await bot.send_message(cl.from_user.id, f'پیام با موفقیت ارسال شد ✅\nپیام 👇🏻 : \n\n{text.text}')
        

@ApiClient.on_callback_query(admin_cm & filters.regex('bot_help') , group=0)
async def bot_help(bot: Client, cl: CallbackQuery):
       await cl.message.edit_text(f'لطفا نوع گزینه مورد نظر خودتون رو انتخاب کنید 👇🏻',
                                    reply_markup = Buttons.Help)

@ApiClient.on_callback_query(admin_cm & filters.regex('Dastour') , group=0)
async def Dastour_help(bot: Client, cl: CallbackQuery):
       text = (f'▪️▪️▪️▪️▪️▪️▪️▪️\n'
               f'⚡️ <code>/setbanner</code>\n💠 تنظیم بنر سایت\n❈❈❈❈❈❈❈\n'
               f'⚡️ <code>/settext</code>\n💠 تنظیم متن زیرمجموعه \n❈❈❈❈❈❈❈\n'
               f'⚡️ <code>/setform site</code>\n💠 تنظیم لینک سایت \n▪️▪️▪️▪️▪️▪️▪️▪️\n'
               f'⚡️ <code>/setform link</code>\n💠 تنظیم لینک سایت  بدون فیلتر\n❈❈❈❈❈❈❈\n'
               f'⚡️ <code>/setbn</code>\n💠 تنظیم بنر زیرمحموعه گیری\n❈❈❈❈❈❈❈\n'
               f'⚡️ <code>/setform takgame</code>\n💠 تنظیم فرم تک گیم\n▪️▪️▪️▪️▪️▪️▪️▪️\n'
               f'⚡️ <code>/setform ourbots</code>\n💠 تنظیم لیست ربات\n❈❈❈❈❈❈❈\n'
               f'⚡️ <code>/setform shorbet</code>\n💠 تنظیم فرم شوربت\n❈❈❈❈❈❈❈\n'
               f'⚡️ <code>/setaff</code>\n💠 تنظیم متن اطلاع رسانی کاربر ربات\n▪️▪️▪️▪️▪️▪️▪️▪️'
               )
       await cl.message.edit_text(f'{text}',
                                    reply_markup = Buttons.Help_back_)

@ApiClient.on_callback_query(admin_cm & filters.regex('BAck_h') , group=0)
async def Dasdt_help(bot: Client, cl: CallbackQuery):
       await cl.message.edit_text(f'لطفا  گزینه مورد نظر خودتون رو انتخاب کنید 👇🏻',
                                  reply_markup = Buttons.Help)

@ApiClient.on_callback_query(admin_cm & filters.regex('learn') , group=0)
async def learn_help(bot: Client, cl: CallbackQuery):
       await cl.message.edit_text(f'برای تنظیم متن زیرمجموعه <code>LINK</code> حتما داخل متن باشد !\n\n'
                                  f'برای تنظیم متن اطلاع رسانی کاربر ربات <code>NAME</code> و <code>NUM</code> حتما در متن باشند !',
                                  reply_markup = Buttons.Help_back_)

@ApiClient.on_callback_query(admin_cm & filters.regex('Set_join') , group=0)
async def set_join_menu(bot: Client, cl: CallbackQuery):
       await cl.message.edit_text(f'لطفا نوع گزینه مورد نظر خودتون رو انتخاب کنید 👇🏻',
                                    reply_markup = Buttons.set_join)

@ApiClient.on_callback_query(admin_cm & filters.regex('set_ch') , group=0)
async def set_join_(bot: Client, cl: CallbackQuery):
    try:
        text=((await bot.ask(cl.from_user.id,f'<b>لطفا شناسه رو ارسال کنید !</b>',filters=filters.text,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass

    if text.text == '❌ انصراف ❌':
        await bot.send_message(cl.from_user.id, f'سلام مدیر 💎\n🔧 از منوی زیر میتونید ربات را کنترل کنید 🔧', 
        reply_markup = Buttons.Management)

    try:
        b=((await bot.ask(cl.from_user.id,'<b>لطفا اسم دکمه رو ارسال کنید !</b>',filters=filters.text ,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass

    if int(text.text) in SETTINGS['channel_ids']:
        await bot.send_message(cl.from_user.id,'در جوین اجباری ها موجود می باشد ⁉️')
    else:
        name = await bot.get_chat(int(text.text))

        SETTINGS['channel_link'][b.text] = name.invite_link
        SETTINGS['channel_ids'][int(text.text)] = name.invite_link
        save_settings()
        await bot.send_message(cl.from_user.id,f'➕ جوین اجباری جدید ✔️\n®️ نام : {name.title}\n©️شناسه : <code>{text.text}</code>\n➰ لینک :\n<code>{name.invite_link}</code>')

@ApiClient.on_callback_query(admin_cm & filters.regex('del_ch') , group=0)
async def del_join_(bot: Client, cl: CallbackQuery):
    try:
        text=((await bot.ask(cl.from_user.id,f'<b>لطفا شناسه رو ارسال کنید !</b>',filters=filters.text,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass

    try:
        b=((await bot.ask(cl.from_user.id,'<b>لطفا اسم دکمه رو ارسال کنید !</b>',filters=filters.text ,reply_markup=Buttons.Cancel,timeout=120)))
    except TimeoutError :pass

    if text.text == '❌ انصراف ❌':
        await bot.send_message(cl.from_user.id, f'سلام مدیر 💎\n🔧 از منوی زیر میتونید ربات را کنترل کنید 🔧', 
        reply_markup = Buttons.Management)
    try:
        name = await bot.get_chat(int(text.text))
        SETTINGS['channel_ids'].pop(int(text.text))
        SETTINGS['channel_link'].pop(b.text)
        save_settings()
        await bot.send_message(cl.from_user.id,f'➖ حذف جوین اجباری  ✔️\n®️ نام : {name.title}\n©️شناسه : <code>{text.text}</code>')

    except:
        await bot.send_message(cl.from_user.id, 'در جوین اجباری ها موجود نیست ⁉️')



@ApiClient.on_callback_query(group=0)
async def send_b_user_bot(bot: Client, cl: CallbackQuery):

    if cl.data == f'send_javb_admin{cl.from_user.id}':

        try:
            text=((await bot.ask(cl.from_user.id,f'📩 لطفاً پیام خود را ارسال کنید 📩\nمدیریت پس از مشاهده در سریع‌ترین زمان ممکن پاسخ شما را ارسال خواهد کرد 🙏\n\nبرای کنسل کردن /start را بزنید',reply_markup=Buttons.Cancel,timeout=120)))
        except:
            await bot.send_message(cl.from_user.id,'زمان شما به پایان رسید !\nدوباره سعی کنید !')

        if text.text == '/start':
            await bot.send_message(cl.from_user.id, f'✦ به اولین و پیشرفته‌ترین ربات شرطبندی تک بازی در تلگرام خوش آمدید 🤖\n'
                                                    f'❇️ ارائه روزانه یک فرم سیف و مطمئن ❇️\n'
                                                    f'✦ برای استفاده از ربات، لطفا گزینه مورد نظر خود را انتخاب کنید 👇🏻', 
                reply_markup = Buttons.Start)
        
        else:
            if text.text:
                for i in SUDO:
                    txt = (f'- پیام از کـاربر : {cl.from_user.mention}\n'
                        f'- آیدی : <code>{cl.from_user.id}</code>\n'
                        f'- پیام  👇🏻\n'
                        f'┈┅┅━━━━━━✦━━━━━━┅┅┈\n'
                        f'{text.text}')
                    await bot.send_message(i,txt,
                                        reply_markup = Buttons.send_javab)

            else:
                for i in SUDO:
                    txt = (f'- پیام از کـاربر : {cl.from_user.mention}\n'
                        f'- آیدی : <code>{cl.from_user.id}</code>\n')
                    await text.copy(i,caption = txt,
                                    reply_markup = Buttons.send_javab)
            
            await bot.delete_messages(cl.from_user.id, text.request.id)
            await bot.send_message(cl.from_user.id, 'پیام با موفقیت ارسال شد ✅')


