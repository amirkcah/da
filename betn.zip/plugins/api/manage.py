from pyrogram import filters, enums, Client, errors
from pyrogram.types import Message, ChatPermissions
from utils.filters import check, admin_cm
from utils.clients import ApiClient
from utils.config import SUDO
from utils import Buttons
from utils.config import SETTINGS, SUDO, LINKS, Clients, channel_links
from pickle import dump

from os import remove as os_remove
import string, random as rnd, shutil, time as myTime, re, os, sys, pyrogram
from data.database import db

#-----------------------------------------------------
def wFile(input):
    file = open(f"{input}", "w", encoding = "utf8")
    file.close()
#------------------------------------------------------
def save_settings():
    with open('settings.pkl', 'wb') as f:
        dump(SETTINGS, f)
#-----------------------------------------------------
        
@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.command('r'))
async def Reload(_, msg: Message):
    await msg.reply_text(f'<b>Reloaded !</b>')
    os.execl(sys.executable, sys.executable, *sys.argv)   

@ApiClient.on_message(filters.user(SUDO) & filters.private & filters.command('backup'))
async def backup(bot: Client, msg: Message):
    user_id = msg.from_user.id
    await bot.send_document(user_id, "betdata.db")
    await bot.send_document(user_id, "settings.pkl")


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setbanner$'))
async def set_baner_site(bot: Client, msg: Message):
    SETTINGS['site_baner'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'بنر سایت ذخیره شد!')

@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/settext'))
async def set_btext_banere(bot: Client, msg: Message):
    SETTINGS['text_baner'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'بنر زیرمجموعه ذخیره شد!')


@ApiClient.on_message(admin_cm  & filters.command(r'^s'))
async def set_je(bot: Client, msg: Message):
    res = msg.command[1]
    name = await bot.get_chat(int(res))
    if int(res) in SETTINGS['channel_ids']:
        msg.reply('در جوین اجباری ها موجود می باشد ⁉️')
    else:
        SETTINGS['channel_link'][name.title] = name.invite_link
        SETTINGS['channel_ids'][int(res)] = name.invite_link
        save_settings()
        await msg.reply_text(f'➕ جوین اجباری جدید ✔️\n®️ نام : {name.title}\n©️شناسه : <code>{res}</code>\n➰ لینک :\n<code>{name.invite_link}</code>')


@ApiClient.on_message(admin_cm  & filters.command(r'^d'))
async def det_je(bot: Client, msg: Message):
    res = msg.command[1]

    name = await bot.get_chat(int(res))

    try:
        SETTINGS['channel_ids'].pop(int(res))
        SETTINGS['channel_link'].pop(name.title)
        save_settings()
        await msg.reply_text(f'➖ حذف جوین اجباری  ✔️\n®️ نام : {name.title}\n©️شناسه : <code>{res}</code>')
    except:
        await msg.reply('در جوین اجباری ها موجود نیست ⁉️')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setform site$'))
async def set_link_site(bot: Client, msg: Message):
    SETTINGS['link_site'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>لینک سایت با موفقیت ذخیره شد!</b>')

@ApiClient.on_message(admin_cm & filters.regex(r'^/delform site$'))
async def del_link_sitee(bot: Client, msg: Message):
    SETTINGS['link_site'] = 0
    save_settings()
    await msg.reply_text(f'<b>لینک سایت با موفقیت پاک شد!</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setform link$'))
async def set_nofilter_link_site(bot: Client, msg: Message):
    SETTINGS['no_fillter'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>لینک سایت بدون فیلتر با موفقیت ذخیره شد!</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delform link$'))
async def del_nofilter_link_site(bot: Client, msg: Message):
    SETTINGS['no_fillter'] = 0
    save_settings()
    await msg.reply_text(f'<b>لینک سایت بدون فیلتر با موفقیت پاک شد!</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setbn'))
async def set_lin_k_bn(bot: Client, msg: Message):
    SETTINGS['link_baner'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>بنر زیرمجموعه گیری  با موفقیت ذخیره شد!</b>')

@ApiClient.on_message(admin_cm & filters.regex(r'^/delbn'))
async def del_link_bn(bot: Client, msg: Message):
    SETTINGS['link_baner'] = 0
    save_settings()
    await msg.reply_text(f'<b>بنر زیرمجموعه گیری  با موفقیت پاک شد!</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setform takgame$'))
async def set_takgame_form(bot: Client, msg: Message):
    SETTINGS['takgame'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>فرم تک گیم ذخیره شد !</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delform takgame$'))
async def del_takgame_form(bot: Client, msg: Message):
    SETTINGS['takgame'] = 0
    save_settings()
    await msg.reply_text(f'<b>فرم تک گیم پاک شد !</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setform ourbots$'))
async def set_basketball_form(bot: Client, msg: Message):
    SETTINGS['ourbots'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>لیست ربات  ذخیره شد !</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delform ourbots$'))
async def del_basketball_form(bot: Client, msg: Message):
    SETTINGS['ourbots'] = 0
    save_settings()
    await msg.reply_text(f'<b> لیست ربات پاک شد !</b>')


@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setform shorbet$'))
async def set_shorbet(bot: Client, msg: Message):
    SETTINGS['over'] = msg.reply_to_message.id
    save_settings()
    await msg.reply_text(f'<b>فرم شوربت ذخیره شد !</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delform shorbet$'))
async def del_shorbet(bot: Client, msg: Message):
    SETTINGS['over'] = 0
    save_settings()
    await msg.reply_text(f'<b>فرم شوربت پاک شد !</b>')

@ApiClient.on_message(admin_cm & filters.reply & filters.regex(r'^/setaff$'))
async def set_user_suub(bot: Client, msg: Message):
    SETTINGS['join_tx'] = msg.reply_to_message.text
    save_settings()
    await msg.reply_text(f'<b>متن اطلاع رسانی کاربر تنظیم شد !</b>')


@ApiClient.on_message(admin_cm & filters.regex(r'^/delaff$'))
async def del_user_sub(bot: Client, msg: Message):
    SETTINGS['join_tx'] = ''
    save_settings()
    await msg.reply_text(f'<b>متن اطلاع رسانی کاربر حذف شد !</b>')

